from django.apps import AppConfig


class DmqlUrlConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "dmql_url"
