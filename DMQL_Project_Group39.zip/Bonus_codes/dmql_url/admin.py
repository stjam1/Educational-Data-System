from django.contrib import admin

# Register your models here.
from .models import (Studentdetails,University)
admin.site.register(Studentdetails)
admin.site.register(University)
