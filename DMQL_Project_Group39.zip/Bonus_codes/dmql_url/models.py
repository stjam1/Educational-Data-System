from django.db import models

# Create your models here.
# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models


class AddressZip(models.Model):
    zipcode = models.IntegerField(db_column='Zipcode', primary_key=True)  # Field name made lowercase.
    city = models.TextField(db_column='City')  # Field name made lowercase.
    state = models.TextField(db_column='State')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'Address_zip'


class Ethnicity(models.Model):
    ethnic_id = models.IntegerField(db_column='Ethnic_id', primary_key=True)  # Field name made lowercase.
    ethnicity = models.TextField(db_column='Ethnicity')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'Ethnicity'

class University(models.Model):
    university_id = models.IntegerField(db_column='University_id', primary_key=True)  # Field name made lowercase.
    name = models.TextField(db_column='Name')  # Field name made lowercase.
    control = models.TextField(db_column='Control')  # Field name made lowercase.
    website = models.TextField(db_column='Website')  # Field name made lowercase.
    zipcode = models.ForeignKey(AddressZip, models.DO_NOTHING, db_column='Zipcode')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'University'

class Facultydetails(models.Model):
    faculty_id = models.IntegerField(db_column='Faculty_id', primary_key=True)  # Field name made lowercase. The composite primary key (Faculty_id, University_id) found, that is not supported. The first column is selected.
    university = models.ForeignKey('University', models.DO_NOTHING, db_column='University_id')  # Field name made lowercase.
    name = models.TextField(db_column='Name')  # Field name made lowercase.
    gender = models.TextField(db_column='Gender')  # Field name made lowercase.
    ethnic_id = models.IntegerField(db_column='Ethnic_id')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'FacultyDetails'
        unique_together = (('faculty_id', 'university'),)


class Studentdetails(models.Model):
    student_id = models.IntegerField(db_column='Student_id', primary_key=True)  # Field name made lowercase.
    student_name = models.TextField(db_column='Student_Name')  # Field name made lowercase.
    gender = models.TextField(db_column='Gender')  # Field name made lowercase.
    sat_score = models.IntegerField(db_column='Sat_Score')  # Field name made lowercase.
    aid_value = models.IntegerField(db_column='Aid_Value')  # Field name made lowercase.
    degree_completion_time = models.IntegerField(db_column='Degree_Completion_time')  # Field name made lowercase.
    ethnic = models.ForeignKey(Ethnicity, models.DO_NOTHING, db_column='Ethnic_id')  # Field name made lowercase.
    university = models.ForeignKey('University', models.DO_NOTHING, db_column='University_id')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'StudentDetails'


