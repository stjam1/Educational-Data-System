import pdb

from django.http import HttpResponse
from django.shortcuts import render

from .models import University


# Create your views here.
def student(request):
    Universities = University.objects.all()
    Universities = Universities.order_by('university_id')
    context = {'Universities' : Universities }
    return render(request, 'studentdetails.html',context)
